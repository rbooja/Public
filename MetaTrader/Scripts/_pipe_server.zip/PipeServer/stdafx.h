//+------------------------------------------------------------------+
//|                                                 MQL5 Pipe Server |
//|                        Copyright 2012, MetaQuotes Software Corp. |
//|                                              http://www.mql5.com |
//+------------------------------------------------------------------+
#pragma once

#define _WIN32_WINNT     0x0600

#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <tchar.h>
//+------------------------------------------------------------------+
