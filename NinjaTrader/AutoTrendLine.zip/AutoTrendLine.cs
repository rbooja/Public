#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;

#endregion



#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		
		private AutoTrendLine[] cacheAutoTrendLine;

		
		public AutoTrendLine AutoTrendLine(int upperLength1, int upperLength2, int lowerLength1, int lowerLength2, Brush upperLineColor, Brush lowerLineColor)
		{
			return AutoTrendLine(Input, upperLength1, upperLength2, lowerLength1, lowerLength2, upperLineColor, lowerLineColor);
		}


		
		public AutoTrendLine AutoTrendLine(ISeries<double> input, int upperLength1, int upperLength2, int lowerLength1, int lowerLength2, Brush upperLineColor, Brush lowerLineColor)
		{
			if (cacheAutoTrendLine != null)
				for (int idx = 0; idx < cacheAutoTrendLine.Length; idx++)
					if (cacheAutoTrendLine[idx].UpperLength1 == upperLength1 && cacheAutoTrendLine[idx].UpperLength2 == upperLength2 && cacheAutoTrendLine[idx].LowerLength1 == lowerLength1 && cacheAutoTrendLine[idx].LowerLength2 == lowerLength2 && cacheAutoTrendLine[idx].UpperLineColor == upperLineColor && cacheAutoTrendLine[idx].LowerLineColor == lowerLineColor && cacheAutoTrendLine[idx].EqualsInput(input))
						return cacheAutoTrendLine[idx];
			return CacheIndicator<AutoTrendLine>(new AutoTrendLine(){ UpperLength1 = upperLength1, UpperLength2 = upperLength2, LowerLength1 = lowerLength1, LowerLength2 = lowerLength2, UpperLineColor = upperLineColor, LowerLineColor = lowerLineColor }, input, ref cacheAutoTrendLine);
		}

	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		
		public Indicators.AutoTrendLine AutoTrendLine(int upperLength1, int upperLength2, int lowerLength1, int lowerLength2, Brush upperLineColor, Brush lowerLineColor)
		{
			return indicator.AutoTrendLine(Input, upperLength1, upperLength2, lowerLength1, lowerLength2, upperLineColor, lowerLineColor);
		}


		
		public Indicators.AutoTrendLine AutoTrendLine(ISeries<double> input , int upperLength1, int upperLength2, int lowerLength1, int lowerLength2, Brush upperLineColor, Brush lowerLineColor)
		{
			return indicator.AutoTrendLine(input, upperLength1, upperLength2, lowerLength1, lowerLength2, upperLineColor, lowerLineColor);
		}
	
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		
		public Indicators.AutoTrendLine AutoTrendLine(int upperLength1, int upperLength2, int lowerLength1, int lowerLength2, Brush upperLineColor, Brush lowerLineColor)
		{
			return indicator.AutoTrendLine(Input, upperLength1, upperLength2, lowerLength1, lowerLength2, upperLineColor, lowerLineColor);
		}


		
		public Indicators.AutoTrendLine AutoTrendLine(ISeries<double> input , int upperLength1, int upperLength2, int lowerLength1, int lowerLength2, Brush upperLineColor, Brush lowerLineColor)
		{
			return indicator.AutoTrendLine(input, upperLength1, upperLength2, lowerLength1, lowerLength2, upperLineColor, lowerLineColor);
		}

	}
}

#endregion
